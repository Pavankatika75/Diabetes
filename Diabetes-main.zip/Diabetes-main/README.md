# Diabetes
The aim of the project is to find an efficient way of detecting diabetes through machine Learning, Classification algorithms like Decision Tree (DT) and AdaBoost are used. Dataset is taken with several features like age, BMI, Insulin level, no of pregnancies, heredity etc .
